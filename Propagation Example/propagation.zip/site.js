var body = document.querySelector('body');
var outer = document.querySelector('#outer');
var inner = document.querySelector('#inner');
var check = document.querySelector('#check');

var useCapture = true; // Change this to change from capture to bubbling;

body.addEventListener('click',function (event) {
  console.log('body')
},useCapture);

outer.addEventListener('click',function (event) {
  console.log('outer')
},useCapture);

inner.addEventListener('click',function (event) {
  console.log('inner')
},useCapture);

check.addEventListener('click',function (event) {
  console.log('checkButton')
},useCapture);
